## UPM. ETSISI. POO

1. Descomprimir el fichero: `template-poo.zip`
2. Cambiar el nombre de la carpeta con el nombre del proyecto
3. Editar el `pom.xml`
   * Cambiar el nombre del artefacto con el nuevo nombre
   * Establecer la matrícula de los participantes
   * Establecer el nombre y apellidos de los participantes
4. Abrir con IntelliJ

